clear
% Parameters 1
m=3;
c=1;
k=100;

% Parameters 2
m2=2;
c2=1;
k2=100;

% Continuous models
Gc=tf([1],[m c  k]);
Gc2=tf([1],[m2 c2  k2]);

% PRBS signal parameters
%%%%%%%%%%%%%%%%%%%%%%% FILL VALUES %%%%%%%%%%%%%%%%%%%%%%%
figure;
bodeplot(Gc);
[mag, phase, wout] = bode(Gc);
mag = squeeze(mag);
phase = squeeze(phase);
w_g = 9; %iz bodea

dt = 2.77/w_g;
G = stepinfo(Gc, 'SettlingTimeTreshold', 0.05);
settling_time = G.SettlingTime;
T = 1.5*settling_time;
N = T/dt;
N = floor(N);
%%%%%%%%%%%%%%%%%%%%%%% FILL VALUES %%%%%%%%%%%%%%%%%%%%%%%
Ts=dt;
Tsim = 10*T;

% PRBS signal
Ui=idinput(N,'prbs');


% %inicijaliziranje maksimalnog pomaka mase
% max_displacement = 0.1;  
% %simulacija sustava
% [y, t] = lsim(Gc, ui, (0:length(ui)-1)*Ts);
% 
% max_response = max(abs(y));
% 
% %skaliranje 
% scaling_factor = max_displacement / max_response;
% 
% ui = scaling_factor * ui;
% 
% [y_scaled, t_scaled] = lsim(Gc, ui, (0:length(ui)-1)*Ts);
% max_response_scaled = max(abs(y_scaled));
% 
% disp(['Original max response: ', num2str(max_response)]);
% disp(['Scaled max response: ', num2str(max_response_scaled)]);
% disp(['Scaling factor: ', num2str(scaling_factor)]);
% 
% figure;
% subplot(2, 1, 1);
% plot((0:length(ui)-1)*Ts, ui);
% title('Scaled PRBS Input Signal');
% xlabel('Time (s)');
% ylabel('Amplitude');
% 
% subplot(2, 1, 2);
% plot(t_scaled, y_scaled);
% title('System Response to Scaled PRBS Input');
% xlabel('Time (s)');
% ylabel('Displacement');


% Discrete models
Gd=c2d(Gc,Ts, 'zoh');
Gd2=c2d(Gc2,Ts, 'zoh');

theta=[Gd.den{1}(2:3) Gd.num{1}(2:3)]';
theta2=[Gd2.den{1}(2:3) Gd2.num{1}(2:3)]';

a1_ = theta(1);
a2_ = theta(2);
b1_ = theta(3);
b2_ = theta(4);
