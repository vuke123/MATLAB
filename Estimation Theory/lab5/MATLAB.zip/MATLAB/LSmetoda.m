function [hat_theta,MSE]=LSmetoda(u,y,n)

% u-ulazni signal (Nx1)
% y-izlazni signal (Nx1)
% n-pretpostavljeni red modela

% hat_theta-vektor estimiranih parametara
% MSE-srednja kvadratna pogreska estimiranog modela

N = length(u) - n; 

phi = [];
for i = 1:N
    % Extract segments and reverse them
    y_segment = flipud(y(i:i+n-1));  % Flip makes it reverse
    u_segment = flipud(u(i:i+n-1));  % Flip makes it reverse

    % Negate y_segment and concatenate with u_segment
    row = [-y_segment; u_segment]';

    % Append to the phi matrix
    phi = [phi; row];
end

phi_2 = phi.' * phi; 
hat_theta = (phi.' * y) / phi_2; 

y_ = y((n+1):end); 
MSE = ((y_ - (phi *hat_theta)).' * (y_ - (phi * hat_theta)))/(N-n);


end