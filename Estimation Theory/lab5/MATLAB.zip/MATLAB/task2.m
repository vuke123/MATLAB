model_zad2; 
Nsim = 100;

hat_theta = zeros(Nsim);
MSE = zeros(Nsim);

a1 = zeros(Nsim);
a2 = zeros(Nsim);
b1 = zeros(Nsim);
b2 = zeros(Nsim);

for i = 1:Nsim
        sim model_zad2.mdl;
        [hat_theta_curr, MSE_curr] = LSmetoda(u.signals.values, y.signals.values, 2);
        MSE(i) = MSE_curr;
        a1(i) = hat_theta_curr(1);
        a2(i) = hat_theta_curr(2);
        b1(i) = hat_theta_curr(3);
        b2(i) = hat_theta_curr(4);
end

a1_LS = mean(a1);
a2_LS = mean(a2);
b1_LS = mean(a3);
b2_LS = mean(a4);
theta_LS = [a1_LS, a2_LS, b1_LS, b2_LS];

% Stvaranje grafa
figure;

% Crtanje stvarnih parametara (crvena boja)
plot(theta(1), theta(2), 'ro', 'MarkerSize', 10, 'LineWidth', 2); 
hold on;

% Crtanje 100 dobivenih parametara u svakom koraku simulacije (plava boja)
plot(hat_theta(:,1), hat_theta(:,2), 'b*');

% Crtanje očekivanih vrijednosti parametara (zelena boja)
plot(theta_LS(1), theta_LS(2), 'go', 'MarkerSize', 10, 'LineWidth', 2);

% Dodavanje oznaka i legende
xlabel('Parametar a1');
ylabel('Parametar a2');
title('Slika_1');
legend('Stvarni parametri', 'Estimacije parametara', 'Očekivane vrijednosti');

hold off;

% Izračunavanje pomaka (BLS)
difference = theta - theta_LS; % Razlika između stvarnih parametara i očekivanih vrijednosti
BLS = norm(difference, 2); % Euklidska udaljenost (2-norma)

% Prikaz rezultata
disp(['Pomak (BLS) je: ', num2str(BLS)]);

Y =y(n+1:n+N);
U = u(n+1:n+N);

E = Y - Phi*theta; 
Ree = autocorr(E');
Rye = xcorr(Y, E);
Rue = xcorr(U, E);

figure;

subplot(3, 1, 1);
autocorr(E);
title('Autokorelacija rezidualne greške (Ree)');
xlabel('Zaostatak');
ylabel('Autokorelacija');

subplot(3, 1, 2);
plot(Rye);
title('Kros-korelacija između izlaza i rezidualne greške (Rye)');
xlabel('Zaostatak');
ylabel('Kros-korelacija');

subplot(3, 1, 3);
plot(Rue);
title('Kros-korelacija između ulaza i rezidualne greške (Rue)');
xlabel('Zaostatak');
ylabel('Kros-korelacija');


